#ifndef _CONST_H_
#define _CONST_H_

#define OK 0
#define ERR_FILE 1
#define ERR_READ 2
#define ERR_INPUT 3
#define ERR_MEMORY -1
#define BUFFER 120

#endif
