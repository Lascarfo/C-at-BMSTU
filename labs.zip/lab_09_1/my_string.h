#ifndef _STRING_F_
#define _STRING_F_

int my_strcspn(const char *symbols, const char *deps);
char *my_strndup(const char *symbols, int len);
int full_len(const char *symbols);

#endif
