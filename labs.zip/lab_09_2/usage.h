#ifndef _USAGE_H_
#define _USAGE_H_

void usage(void);

#endif
